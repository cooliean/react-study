require("./index.scss");
require("../common/common.js");

console.log("client/page2/index.js");